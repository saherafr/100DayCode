# LeetCode

> Day 1
> 

## Encode Decode problem: LC Med-Array

Input: Gives you a list of strings  

Output: return the same list is same format

Mainly design an algorithm to manipulate the string and again change the string in same order without using any extra data Structure

How to do?

Algorithm:

convert the entire list of string to a string that will start with the len of str a special character and the string

_Encoding was easy

1. create a new string 
2. Do a for loop and keep adding into the new string in this format =len+#+str
3. return the new str

_Decode

1. we have the str from encode and now its time to decode
2. start a new list-it will be returned at end and a pointer to track
3. start looping over str till the end and now we need one more pointer
4. that pointer will find the special character for each str
5. now we have like “4#neet” i=4 and j= #
6. we extract the length by doing some slicing op str[i:j] here j will not be included so we get “4”. and we convert that to int. 
7. our length 4 basically starts after the character so we need to extract the words now by doing the same splicing that will start from j+1 : j+1+length
8. we now have the str and we will append that to the list
9. Also we need to update the i pointer for next str

Time & Space Complexity:

1. Time should be O(n) in encode the length of str
- `.append()` is O(1)
- `''.join(res)` is O(n) total

2.Decode

Time and Space both are O(len of str+total str)

Error I encountered:

1. I tried to encode with “4neet#” caused an error because theirs possibility of the sts having # and int in them

1. in encode i created a space res=” “ which made the entire str starting with a space causing index out of bound

## Products of Array Except Self LC Medium

Input: Array of int

Output: Array of int

Restriction: Dont use div operator

Statement of problem: Suppose u have an array and you want to return the array element wise product but without the current index.

[1,2,3,4]=[24,12,4,3] 

Brute force: do to for loops one before the current index and other after and keep multiplying. It doesnt give us optimal result the time com would be 0(n^2)

Solve:

We are doina suffix and prefix product of each arrays

prefix=[1,1,1,1] suffix=[1,1,1,1]

now we go over our original array and keep updating the prefix like prefix[i]=prefix[i-1]*arr[i-1] this will make sure we are excluding i in their current index

Similarly we will do that for suffix but in reverse.

Now we init a new array an empty one and keep multiplying suffix and prefix in their respective index element wise

__because of init a new array we are using space of 0(n) and the time is also 0(n) as single for loops are running each time.

Variation?

Instead of product their can be asked for summation then we init the suff and pref array as [0]*n and inside for loops we do + instead of *

## **Longest Consecutive Sequence LC Med**

Input: a list of int 

Output: return their longest sequence

Time and space complexity 0(n)

Process:

Brute Force:

1. We can do sorting of nlogn then 
2. convert the array into set for avoiding duplicates and for lookups
3. [1,2,3,4,8,9] suppose we have this array and we will do a loop over the array and start finding +1 elements .
4. we will also have a counter to keep track of ength of each seq
5. problem is its nlogn but we can do better with 0(n)

Optimal

1. Convert the array to hashset
2. Now here’s the trick as we cant sort we need to find the start of seq manually in loop 
3. Loop over the set → find when i-1 not in the set
4. Once we find the start of seq then we will use a local counter l=1 as the length of the seq will start from one
5. Now we will start another loop inside it to find the consecutives
6. When we find the consecutives we will keep incrementing our local tracker l
7. after finishing it we will find the max_length

> Day 2
> 

## Valid Sudoko-LC Medium

Input: A 9*9 grid

Output:bool

Constraints:Each row must have unique digits from 1-9 each column must have unique digits fro 1-9 also the sub grid 3*3 sq should have no duplicates from 1-9

1. As we were mentioned no duplicates the first thing will come in our mind as hashset.We need 3 hashset as values for dict for our row col and sq. This will look like row={0:{},1:{},…..8:{}}
2. The sq will be a bit different why? the square is a sub grid of 9*9 [grid.So](http://grid.So) each sq is 3*3 grid. So when we do calc for sq in terms for row and col we need r//3,c//3
3. We start looping over. We need nested for loops to go over rows and colms. If the current cell like board[r][c] is empty we continue to next step.
4. Now we need to start lookups in our hashsets. So board[2][3]==5 in our row we have {1:{2,3},2:{5,8}….} in 2nd row we have 5 in the set that means we are having a duplicate. So the board is invalid. We do this for row col and sq. If any of them is showing True our board will be invalid
5. if not we start adding that board[r][c] element is row[r] col[c] and sq[r//3][c//3]

### Time & Space Complexity

**O(N²) time happens here**

```
for r in range(N):
```

```
for c in range(N):
```

→ These two loops visit every cell once.

- Each `rows[i]`, `cols[j]`, and `squares[(i//3, j//3)]` stores **unique digits** from the board
- In the worst case, we could store up to:
    - N unique values in each of the N rows → N × N
    - Same for columns
    - Squares are ~N total (if generalized), each holding up to N values
- So total memory = **O(N²)**

# Pointer

## Valid palindrome-LC Easy

Input-A string that can have spaces, alphanumerics, punctuations

Output:Bool

**A palindrome is a string that reads the same forward and backward. It is also case-insensitive and ignores all non-alphanumeric characters.**

Process:

1. Have 2 pointers one at left most and one at right most
2. We start looping over it. If we encounter a space we will move our pointer left to +1 and right to -1
3. Now we compare the both str in their lowercase form
4. If itsnt true we return false and our program stops here
5. otherwise we will shift pointers

Dumb Shit I did:

Tho my soln was accepted it could be optimized . So at first I did a new str with lower case no punc. This didnt cause trouble to time bt took extra space

The above process is the optimized one as the time comp is 0(n) as we will loop over entire str of len n. And space is 0(1) we are doing everything inside the given str . Not taking up anything extra to take up memory

## ***Two Integer Sum II LC Med***

Input: Array of Int, Sorted, Target int

Output: 1-indexed list

COnstraints: Must be done with no additional space 0(1) and time 0(n)

Process:

1. we have 2 pointers on 2 sides of the array
2. Start a loop till left meets right
3. Inside loop we keep checking if num[left]+num[right] is less than or greater than 1. if its less that means we need to increment left pointer to get a bigger sum. If its more we will shift the right pointer.
4. When we find something that’s equal our target we add +1 to both left and right and return like this[left+1,right+1]. As the left pointer is always less than right we dont have to do any thing more

As we are traversing the whole array the time complexity would be its len and spae is constant.

For Brute force we do 2 for loops to keep checking with target. For 2 loops the time complexity can go upto n^2 while space is constant.

## *Container with most water LC MED*

### Key Concepts:

- Use **two pointers**: one at the start, one at the end
- **Area = width × min(height1, height2)**
- Always move the pointer pointing to the **shorter height**, because moving the taller one can’t increase area

---

### ⏱ Time & Space:

- **Time:** O(n) — each index visited at most once
- **Space:** O(1) — no extra memory used

---

### 💡 Intuition:

- The width is largest at the start, but height might be small.
- As you move inward, width shrinks, so you only want to move **toward a potentially taller wall** to maximize area.

> Day 3
> 

## Three Sum – Leetcode Medium

### ✅ What was asked:

Given an array, find all unique triplets that sum to 0. Can’t use the same index more than once, and final output **should not have duplicate triplets**.

---

### 🧠 My Initial Logic:

Sorted the array and used a for loop to fix one number `nums[i]`, then used two pointers (`j = i + 1` and `k = len(nums) - 1`) to find two numbers such that:

```python

nums[i] + nums[j] + nums[k] == 0
```

I pushed all matches into a result list. Here’s the rough structure:

```python

for i in range(len(nums)):
    target = -nums[i]
    j = i + 1
    k = len(nums) - 1
    while j < k:
        if nums[j] + nums[k] < target:
            j += 1
        elif nums[j] + nums[k] > target:
            k -= 1
        else:
            res.append([nums[i], nums[j], nums[k]])
        j += 1
        k -= 1
```

---

### ❌ What Went Wrong:

1. **I moved `j += 1` and `k -= 1` outside the `else` block.**
    
    This caused the pointers to shift even when the current sum didn’t match the target. So it was skipping potential valid pairs.
    
2. **Didn’t handle duplicate values.**
    
    For example, if the input was `[-1, -1, 2, 2]`, it returned multiple copies of the same triplet `[-1, -1, 2]`.
    
    LeetCode requires **no duplicate triplets**, even if input has duplicate values.
    

---

### ⚠️ Edge Case that Exposed It:

Input:

Expected Output:

```python

[[0, 0, 0]]
```

But I was getting:

```python

[[0, 0, 0], [0, 0, 0]]
```

---

### 🔑 Rule of Thumb to Remember:

- Always **skip duplicates** for all three positions:
    - Skip duplicate `nums[i]` in the outer loop
    - Skip duplicate `nums[j]` and `nums[k]` in the inner loop after a match
- Only move `j` and `k` inside the `else` block (i.e., when a triplet is found)
- Always **sort the array first** for two-pointer logic to work properly

---

### ⏱️ Time & Space Complexity:

- **Time:** `O(n^2)`
    
    One for loop `O(n)` and two-pointer loop inside it `O(n)`
    
- **Space:** `O(1)` (excluding the output list)

## Buy and sell stocks-LC easy

Input: Array of prices where the prices[i] is is the price of ith day

output: Find max profit

Time Complexity 0(n) and space complexity 0(1) so we cant do any extra spacing like new array or hmap etc

process:

To make profit it is important to buy at lesser price and sell at more.

WE WILL do a sliding window technique where it will keep checking till the end dynamically by expanding and shrinking the window

1. Suppose the entire array is our window 
2. We have 2 pointers one at the very beginning of window and 1 just a step ahead. Consider the window a bit open.
3. Now the duty of the distant pointer which is ahead is to keep expanding till the end(we will check this in while loop<len)
4. Now its time to find whether the selling price(distant) is more than the buying the initial point.
5. If it is, that means we have our profit. Now we will update that in our max_profit
6. if we see that the selling price is less than buying we will jump our buying pointer to the selling pointer
7. we will expand the selling pointer of window

## **Longest Substring Without Repeating Characters-LC med**

Input: A string

Output:length of string

Time Complexity: 0(n)

Space COmplexity: 0(m)

Process

1. We were asked to find the longest [substrings.Like](http://substrings.Like) the length of longest seq that doesnt have any duplis. is the str is abcabbs Then the max len would be abc.
2. We got the space of m→ len of a substring so we can do a hashset to avoid duplis.We also need max_len to keep track of length
3. using the sliding window algo lets start our window(given string) as closed.That means both points are at starting index.
4. We start expanding our window with one of our pointer and the condition would be it will go till the last [str.So](http://str.So) our window will be wide opened
5. Now we check whether the dynamic point the moving one is in our hset or not
6. If it is, we will start shrinking the window from left side. How do we do that? We basically hop our the other pointer to one step and remove that element from the hset. We will keep doing until there’s no duplis
7. Whatif we do not encounter duplis in hset?
8. We add that dynamic element in our hset and calculate the length of current substring by r-l+1 .beacause we are doing with 0 indexed
9. Along that we need to comparing with prevoius results and update the max

The time complexity 0(n) is due to the for loop going till the end and the space complexity 0(m) we store the strs when there’s no duplis

> Day4
> 

**Longest Repeating Character Replacement- Lc Med**

**Problem:**

Given a string `s` and an integer `k`, return the length of the longest substring where you can replace **at most `k` characters** to make all characters the same.

**Example:**

`s = "AAABABB"`, `k = 1` → Output: `4` (Longest substring: `"AABA"` or `"ABBB"`)

---

### **Approach: Brute-force over charset + Sliding Window**

**Key Idea:**

Try every unique character `c` in `s` and use a sliding window to keep the count of how many `c`s exist. Replace all non-`c` chars inside the window. If more than `k` replacements needed → shrink window.

---

### **Steps:**

1. **Init:**
    - `res = 0` (max window length)
    - `charSet = set(s)` (e.g. `{"A", "B"}`)
2. **Outer loop** on each `c in charSet`
    
    Try making all chars in window equal to `c`.
    
3. **Inner loop** with sliding window:
    - `l = 0`, `count = 0` (number of times `s[r] == c` in current window)
4. **If** `s[r] == c`, increment `count`.
5. **While** `(window length) - count > k`:
    
    Means more than `k` changes needed → shrink window from left
    
    - If `s[l] == c`: decrement `count`
    - Increment `l`
6. **Update `res = max(res, r - l + 1)`** after each `r`

---

### **Shrink Example Walkthrough:**

Let’s say:

- `r = 6`, `l = 0`, `count = 5`, `window length = 7`
    
    → `7 - 5 = 2 > k`
    
    → Too many replacements → shrink from left
    
- Check if `s[l] == c`: Yes → decrement `count`, `count = 4`, `l = 1`
    
    → New: `r = 6`, `l = 1`, `window length = 6`, `count = 4`
    
    We only decrement count when s[l]==c otherwise it will change the count thats not doing anyhting
    
    → `6 - 4 = 2 > k` → shrink again
    
    → Now `l = 2`, `count = 3` → `5 - 3 = 2` → still bad
    
    → `l = 3`, `count = 3`, `r - l + 1 = 4`, `4 - 3 = 1 ≤ k` → OK
    

---

### **Time Complexity:**

- Outer loop: `O(26)` (max 26 letters)
- Inner loop: `O(n)`
- Total: **O(26n) → O(n)**

### **Space Complexity:**

- **O(1)** for set and counters

# Permutation in String

**Medium**

**You are given two strings `s1` and `s2`.**

**Return `true` if `s2` contains a permutation of `s1`, or `false` otherwise. That means if a permutation of `s1` exists as a substring of `s2`, then return `true`.**

**Both strings only contain lowercase letters.**

**Example 1:**

```java
Input: s1 = "abc", s2 = "lecabee"

Output: true

```

**Copy**

**Explanation: The substring `"cab"` is a permutation of `"abc"` and is present in `"lecabee"`.**

**Input:**

- `s1`: a small string (whose permutation we’re looking for)
- `s2`: a larger string (in which we look for a matching substring)

**Goal:**

Check if **any permutation of `s1`** is a **substring** of `s2`.

---

## 🧠 Key Concept:

A permutation of a string has the **same characters, same frequencies** — just shuffled.

So:

✅ If a substring of `s2` has **exact same character counts as `s1`**, it is a permutation.

---

## ✅ Solution Strategy: Sliding Window + Frequency Array

### Step-by-step Logic:

1. ❌ If `s1` is longer than `s2`, return `False` (it can’t be a substring)
2. ✅ Create two arrays of size 26 for character counts:
    - One for `s1`
    - One for the first window in `s2` (same size as `s1`)
    
    These arrays are of size 26 because there are 26 lowercase English letters.
    
    All values start at 0 by default.
    
3. ✅ Compare both arrays. If all characters match → it’s a permutation.
4. ✅ Use a **sliding window** on `s2`:
    - Each time, add one new character to the window (from the right)
    - Remove one old character (from the left)
    - Keep track of how many characters are still **matching** between `s1Count` and `s2Count`
    - If all 26 characters match → return `True`

---

## 💡 `matches` Variable — What’s That?

We use a variable `matches` to track **how many characters currently match** between `s1` and the sliding window in `s2`.

If `matches == 26`, it means:

> “All letters (even 0s) are equal → it’s a permutation!”
> 

---

## 🔁 Your Confusion: Why loop only `len(s1)` to fill counts?

```python
python
CopyEdit
for i in range(len(s1)):
    s1Count[ord(s1[i]) - ord('a')] += 1
    s2Count[ord(s2[i]) - ord('a')] += 1

```

🧠 You're looping only over the **length of `s1`**, not all 26 letters, because:

- You’re just **updating the counts** of the actual characters present.
- The rest of the array is already `0` — no need to touch them.
- Later, we check all 26 characters using:

```python
python
CopyEdit
for i in range(26):
    if s1Count[i] == s2Count[i]:
        matches += 1

```

---

## 🤯 Your Big Confusion: Why `s2Count` still works for all 26 if we didn’t fill all indexes?

Because we initialized it with:

```python
python
CopyEdit
s2Count = [0] * 26

```

So:

- Even if you didn’t explicitly touch every index (letter), it still has value `0`
- So we can compare all 26 safely

---

## 🔁 Sliding Window Walkthrough

We slide one letter at a time.

At each step:

- **Add** one new letter (`r`)
- **Remove** one old letter (`l`)
- Update the frequency count accordingly
- Adjust `matches` based on how this affects character matching

---

## ❓ Your Confusion: Why use these 2 special `elif` conditions?

```python
python
CopyEdit
if s1Count[index] == s2Count[index]:
    matches += 1
elif s1Count[index] + 1 == s2Count[index]:
    matches -= 1

```

You asked:

> Why not just do else: matches -= 1?
> 

### 🎯 The Reason:

Let’s say `'c'` was **already mismatched** (e.g. `s1Count[c] = 0`, `s2Count[c] = 3`)

Then you **add another `'c'`** → it becomes `4`

→ It was already mismatched — it **stays mismatched**

🚫 You should **NOT** reduce `matches`, because it was never matching!

✅ We only adjust `matches` when:

- A match is **just created** → `==`
- A match is **just broken** → `+1` or `1` mismatch

That’s why we don’t use a basic `!=` or `else`.

---

## 🎯 Summary: What You Must Remember

| 🔍 Action | What to Check | What to Do |
| --- | --- | --- |
| Add new char | If it now matches → `matches += 1` | Else if it broke a match → `matches -= 1` |
| Remove old char | If it now matches → `matches += 1` | Else if it broke a match → `matches -= 1` |
| Final Check | If `matches == 26` | Return `True` |

---

## ✅ Final Return:

```python
python
CopyEdit
return matches == 26

```

This checks the last window after the loop ends.

---

## 🧾 Takeaway:

- Sliding window is used to avoid recalculating everything from scratch
- `matches` keeps track of how many letters have equal counts
- We only adjust `matches` when a character transitions from "matching" ↔ "not matching"
- That's why we use `+1` and `1` comparisons — not just `!=`

Day 5

Binary Search-LC easy

Input: Int array and target

Ountput: Index of target else -1

Time Cons: 0(logn) → can only be done with binary search cux we have space limitation of 0(1)

How to do?

→ Our array will already be sorted. So we init two pointers on 2 end of array

→ Thumb rule of bin search we have to look for each and every elememnt until left and right pointers isnt pointing at one

### `while left != right` → means:

> “Stop when both pointers meet.”
> 

So, when `left == right`, it **breaks immediately**, even though there’s **still one element to check**.

This leads to missed answers.

→calc the mid →left+(right-left)//2

→check the targets if target >num[mid] e move our left pointer skipping the mid. Why? we already saw our target is larger then that so its obvious our ans doesnt belong to the first half of array including mid

→ Same will go for < case

→When equal we return the index

## 🧠 How to Do Binary Search in a 2D Matrix-LC med

**Use this when the matrix is sorted row-wise, and each new row starts with a number bigger than the previous row’s last number.**

---

### 💡 Problem Setup:

You are given a matrix like this:

What I noticed:

- Each row is sorted ✅
- The first number in a row is greater than the last number in the previous row ✅
    
    ➡️ So if you flatten the matrix, it behaves like one big sorted 1D array.
    

---

### ✅ Thought Process & Steps:

### 1. Treat the 2D matrix like a 1D array

- Total elements = `rows × cols`
- Use **binary search** between indexes `left = 0` and `right = (rows × cols) - 1`

### 2. Binary Search loop:

```python
python
CopyEdit
while left <= right:

```

Use this (NOT `left != right`) so that we also check the case where one element is left.

### 3. Calculate the mid safely:

```python
python
CopyEdit
mid = left + (right - left) // 2

```

This avoids overflow in other languages and is always safe.

### 4. Convert 1D `mid` into 2D:

```python
python
CopyEdit
row = mid // cols
col = mid % cols

```

- `//` gives which row
- `%` gives position inside that row (column)

### 5. Do the comparison:

```python
python
CopyEdit
if matrix[row][col] == target:
    return True
elif target < matrix[row][col]:
    right = mid - 1
else:
    left = mid + 1

```

### 6. If loop ends, return False (target not found)

---

### 📦 Final Takeaways:

- This matrix problem **can be solved exactly like a 1D binary search**, with only one difference:
    
    👉 You convert the index into row/col using `//` and `%`
    
- Think of the matrix like a **flattened sorted array** where every element has a virtual index

---

### KOKO Bananas-LC med

→ We ned to find the min hours to fininsh all the bananas

→ Now koko can eat max 1 entire pile in 1 hour and minimum as 1. So its limit is 1 to max(piles)

→We will do binary search on this k={1,……,max(piles)] This is rate of banana eating banana/hour

→ as usual we find the mid of this array list of speed banana per hour [1,2,3,4,5,6,7,8,9,10] so 5 is our mid here. We have the spped of eating 5 bananas in 1 h. Now we go over the entire pile of banana of check

we do for loop and calculate the hours+=bananna/(banana/hr).Now we know with the rate of 5 how much time it will take koko to eat he entire pile

→ we were given h. so we compare whether our total h is lesst than or equal to given h. if it is we update our result=mid then we shift our right pointer to the left side 

→ do the reverse here

→ At the end we return the res

→ Now the res will only be updated if the eating hour of koko is less than or equal to h and thats how the min will be returned. beause by slowing down the rate it takes for time than h we are done here.

> Day 6
> 

## LeetCode: Find Minimum in Rotated Sorted Array

**Difficulty:** Medium

**Pattern:** Binary Search

**Asked In:** Amazon, Google, Microsoft

---

### 🧠 Problem Summary:

You're given a **rotated sorted array** with all **unique integers**.

Your task is to **find and return the minimum element**.

The challenge: Solve it in **O(log n)** time.

---

### 🎙️ Interview Flow:

### ❓ **Interviewer:**

"Let’s start simple. What’s the brute-force way to solve this?"

### 💡 **Candidate (You):**

"Scan the array and track the smallest value by comparing every element."

- Time: O(n)
- Space: O(1)
- ❌ Not optimal — we need to reduce time to **O(log n)**

---

### 🎯 Optimization Insight:

> The array is partially sorted — which means we can use binary search instead of linear search.
> 

---

### 🧩 Core Idea:

- The array was originally sorted and rotated. So it's made of **two sorted subarrays**.
- The **minimum element** lies at the **point where the rotation caused a “drop”** (e.g., from 7 to 1).
- We use binary search to **detect which half** of the array contains that drop.

---

### 🔍 Binary Search Logic (Explained in Words):

1. Start with two pointers — `left` and `right` — at the ends of the array.
2. Find the `mid` index between them.
3. Compare the value at `mid` with the value at `right`.
    - If the middle value is **greater** than the rightmost value → the **minimum must be in the right half**.
    - If the middle value is **less** than the rightmost value → the **minimum is at mid or in the left half**.
4. Keep shrinking the search space until `left == right` — this gives you the **position of the minimum**.

---

### 🧠 Why This Works:

- The binary search always **retains the minimum** within the search range.
- Because we’re cutting the search space in half every step, the runtime is **O(log n)**.
- The loop stops when **left and right converge** — meaning we’ve found the minimum.

---

### 📦 Edge Case to Consider:

**If the array is not rotated at all** (e.g., `[1, 2, 3, 4, 5]`):

- The binary search still correctly identifies the first element as the minimum.
- This shows the approach is robust even when there's **no rotation**.

---

### 📌 Final Key Takeaways:

- Compare `mid` with `right`, **not with `left`**, to detect which half to search.
- If the middle value is **greater than right**, the minimum is to the **right of mid**.
- If the middle value is **less than or equal to right**, the minimum is in the **left half including mid**.
- When the loop ends, **`left == right`** — and that is the **index of the minimum**.

## LeetCode: Search in Rotated Sorted Array

**Difficulty:** Medium

**Concept:** Modified Binary Search

**Pattern:** Rotation-aware binary search with sorted-half checking

---

### 🧠 Problem Summary

You are given a **rotated sorted array** of **unique integers** and a **target value**.

Your task is to return the **index** of the target if it exists, or `-1` otherwise.

The solution must run in **O(log n)** time.

---

### 🤔 Why is this tricky?

In a normal sorted array, you can easily use standard binary search.

But this array is **rotated**.

Example:

Original: `[0, 1, 2, 3, 4, 5, 6]`

Rotated: `[4, 5, 6, 0, 1, 2, 3]`

This rotation breaks the full sorted order — so you need to detect which half of the array is sorted at each step.

---

## 🔄 High-Level Strategy

Each time you calculate the middle index:

1. **Check if the target is at mid** — return index if so.
2. **Identify which half is sorted** — left or right.
3. **Check if the target lies in that sorted half.**
4. **Discard the half where it cannot exist.**
5. Continue shrinking your search range.

---

## 🔍 The Key Decision Logic (Target Location)

### ✅ Case 1: Left half is sorted

You know this if the **leftmost element is less than or equal to mid**.

Now ask:

> Is the target between the left and mid?
> 
- If yes → stay in this half.
- If no → search in the right half.

---

### ✅ Case 2: Right half is sorted

If the left half is not sorted, then the right half must be.

Now ask:

> Is the target between the mid and right?
> 
- If yes → search in the right half.
- If no → search in the left half.

---

### ❗ Target-Location Confusion Tip

When people get confused, it’s usually here:

You **do not** just compare `target` to `mid`.

You compare `target` to the **boundaries of the sorted half**:

- If the **left half is sorted**, ask:
    
    ➤ Is `target` between the **left boundary** and **mid**?
    
- If the **right half is sorted**, ask:
    
    ➤ Is `target` between the **mid** and **right boundary**?
    

Use **inclusive comparison**:

- Is target ≥ lower bound **and** ≤ upper bound?

---

## 💡 Important Edge Cases

- If the array is **not rotated** at all → logic still works
- If the **target is not present** → you'll reduce the search range to nothing and return -1
- If the **target is at mid**, you return instantly

---

### 🧠 Summary

- A rotated array always has **one sorted half**
- You must:
    - Identify which half is sorted
    - See if target lies inside that half
    - Eliminate the wrong half efficiently

Day 7

Linked List

## Reorder Linked List — Thought Process (Beginner-Friendly)

### 🔍 Problem Summary:

We’re given a singly linked list.

We need to **reorder it in-place** to follow a pattern like this:

```
makefile
CopyEdit
Original:  [0, 1, 2, 3, 4, 5, 6]
Reordered: [0, 6, 1, 5, 2, 4, 3]

```

> ✅ Important: We can’t create new nodes or modify node values.
> 
> 
> ✅ We must reorder **by changing the `.next` pointers only**.
> 

---

## 🧠 Strategy Overview:

We break this into 3 clean steps:

---

### 🥇 Step 1: **Find the middle of the list**

- Use **slow and fast pointers**:
    - `slow` moves 1 step at a time
    - `fast` moves 2 steps at a time
- When `fast` reaches the end, `slow` is at the **middle**

📌 Why?

This helps us **split the list** into two halves:

- First half: from head to middle
- Second half: from middle to end

---

### 🥈 Step 2: **Reverse the second half of the list**

- From the node after the middle, we reverse the second half in-place.

📌 Why?

Because we want to **zip the list** together:

- Take one node from front
- Then one node from back
- Then next front, then next back, etc.

---

### 🥉 Step 3: **Merge the two halves**

- Now we have:
    - First half: in original order
    - Second half: reversed

We now **interleave** them like a zipper:

- First node from left half
- First node from reversed right half
- Second node from left
- Second node from reversed right
- ...

📌 Tip:

Make sure to:

- Keep track of `.next` pointers during interleaving
- Set the `.next` of the final node to `None` to avoid cycles

---

## 💡 Final Notes:

- We don’t return anything — the function modifies the list in-place.
- This approach uses:
    - ✅ **O(n)** time
    - ✅ **O(1)** space (no extra memory)

---

---

## 🔁 Detect Cycle in Linked List — Thought Process

### 🔍 Problem Summary:

You're given the head of a singly linked list.

You need to determine **whether there's a cycle** in the list — that is, whether following `.next` links leads you back to a node you've already visited.

📌 A cycle means:

Some node's `.next` points **backward** in the list, forming a loop like:

```
mathematica
CopyEdit
A → B → C → D → E
          ↑     ↓
          H ← G ← F

```

---

## 🧠 Strategy Overview

### 🥇 Step 1: **Detect if a cycle exists**

Use the **Floyd’s Cycle Detection Algorithm** (Tortoise and Hare 🐢🐇):

- Start two pointers (`slow` and `fast`) at the head
- Move:
    - `slow` → 1 step at a time
    - `fast` → 2 steps at a time

✅ If `fast` ever equals `slow`, a cycle exists

❌ If `fast` hits the end (`None`), there's no cycle

📌 Why it works:

On a circular track, a faster runner will **always catch up** to the slower runner if a loop exists.

---

## 🧩 Recruiter Follow-Up:

### ❓"Can you return the **starting node** of the cycle, not just whether it exists?"

This is the **most common twist** to the base problem.

---

### 🥈 Step 2: **Find the entry point of the cycle**

Once `fast == slow` (they’ve met inside the loop):

1. Keep `slow` at the meeting point
2. Start a **new pointer** from the head
3. Move both `slow` and new pointer **1 step at a time**
4. Where they meet again → that’s the **start of the cycle**

📌 Why this works:

Mathematically, they’ll both be the same number of steps away from the start of the cycle when this step begins.

---

## 🧪 Edge Cases to Watch For

- ❌ Empty list → return False immediately
- ❌ Single node pointing to None → return False
- ✅ Single node pointing to itself → return True
- ✅ Cycle starts at head → fast and slow will eventually meet

## 🧠 Problem: Add Two Numbers (Linked List)

You're given two **non-empty** linked lists representing two non-negative integers.

Each node contains **a single digit**, and the digits are stored in **reverse order**.

> You need to return a linked list representing the sum of the two numbers, also in reverse order.
> 

---

## 🎯 Core Concepts

### ➤ Reverse Order:

- `l1 = [2, 4, 3]` means the number **342**
- `l2 = [5, 6, 4]` means the number **465**
- Total = `342 + 465 = 807`
- Result should be: `[7, 0, 8]`

---

## 🔁 Thought Process (Step-by-Step)

### ✅ 1. Initialize Key Variables

- `carry = 0`: This keeps track of digits greater than 9
- `dummy`: A starting node to help build the resulting list
- `current`: A moving pointer that appends new result digits to `dummy`

---

### ✅ 2. Loop Condition

We loop **as long as we have**:

- Nodes left in `l1`
- Nodes left in `l2`
- A carry value left to process

**Loop condition**:

```
text
CopyEdit
while l1 or l2 or carry:

```

This ensures we process all digits and any leftover carry at the end.

---

### ✅ 3. Digit Extraction

At each step:

- Get `val1 = l1.val` if `l1` exists, otherwise `0`
- Get `val2 = l2.val` if `l2` exists, otherwise `0`

This allows for **uneven-length lists** to be handled smoothly.

---

### ✅ 4. Addition Logic

For each digit:

- Compute `total = val1 + val2 + carry`
- The digit to store in the new node = `total % 10`
- The new carry = `total // 10`

This mirrors how we do math on paper!

---

### ✅ 5. Move Pointers Safely

Move to the next digit only **if the list exists**:

```
text
CopyEdit
if l1: l1 = l1.next
if l2: l2 = l2.next

```

This avoids crashing on a `NoneType`.

---

### ✅ 6. Final Step

After the loop ends:

- Return `dummy.next` — which skips the initial dummy node and gives you the real result list.

---

## 🧪 Dry Run: l1 = [9, 9], l2 = [1]

### Step 1:

- 9 + 1 + 0 = 10 → digit = 0, carry = 1
    
    → Result = [0]
    

### Step 2:

- 9 + 0 + 1 = 10 → digit = 0, carry = 1
    
    → Result = [0, 0]
    

### Step 3:

- l1 and l2 are done, but carry = 1
    
    → Add new node with 1
    
    → Result = [0, 0, 1]
    

Final number: **100**

Reverse list: `[0, 0, 1]`

---

## 🚨 Edge Cases to Know

| Case | Behavior |
| --- | --- |
| Uneven lengths | Use 0 for missing nodes |
| Final carry left | Add an extra node |
| One list is [0] | Still adds properly |
| Both lists are [0] | Output is [0] |

---

## 🧠 Interviewer Will Look For:

- Did you use a **dummy node**?
- Did you handle **carry at the end**?
- Did you safely move through `l1` and `l2`?
- Did you check for **off-by-one** errors?

---

## ✅ Final Output Always:

The result is a new linked list built from scratch — dummy node helps avoid special casing the head.

Day 8

# 📘 LeetCode Deep Dives – Pattern-Based Learning Notes

---

## 🧩 Problem 1: Find the Duplicate Number (Floyd's Cycle Detection)

### 🔍 Problem Statement

You’re given an array `nums` of length `n + 1`, where each number is in the range `[1, n]`. Exactly one number is duplicated (may appear multiple times).

Return the duplicated number.

### ✅ Brute Force Insight

- Use a `set()` to track seen values
- Return the number the moment it appears twice
- ⏱ Time: O(n), ❌ Space: O(n)

---

### 🚀 Optimal Approach: Floyd’s Cycle Detection

Treat `nums[i]` as a pointer to index `nums[i]`. This forms a linked list where a cycle must exist due to the duplicate.

### 🔁 Phase 1: Detect Cycle

- Initialize: `slow = nums[0]`, `fast = nums[0]`
- Loop: `slow = nums[slow]`, `fast = nums[nums[fast]]`
- When `slow == fast` → cycle detected

### 🎯 Phase 2: Find Entrance to Cycle

- Set `finder = nums[0]`
- Move both `finder = nums[finder]`, `slow = nums[slow]` until they meet
- Return the meeting point → the duplicate

---

### 🧠 Why This Works

- Duplicate creates a cycle in the index-graph
- Detecting the start of the cycle = finding the repeated number
- ⏱ Time: O(n)
- 🧠 Space: O(1)
- 💯 Works for all valid inputs (e.g. `[1,1]`)

---

## 🧩 Problem 2: LRU Cache (System Design + Hash + List)

### 🔍 Problem Statement

Design an LRU (Least Recently Used) Cache that:

- Returns value with `get(key)`, else `1`
- Updates/inserts key with `put(key, value)`
- Evicts least recently used key if capacity is exceeded

Each operation must run in ⏱ O(1) time.

---

### 🔑 Core Idea: Dict + Doubly Linked List

| Data Structure | Role |
| --- | --- |
| `dict` | `key → node` lookup in O(1) |
| Doubly Linked List | Track usage order in O(1) |
| Dummy Head/Tail | Simplify insert/remove edge cases |

---

### ✨ OrderedDict Shortcut (Python Only)

- Keeps key order by usage
- `move_to_end(key)` → mark as recently used
- `popitem(last=False)` → remove least recently used (front)

---

### 🛠 Method Summary

**`__init__(capacity)`**

- Initialize OrderedDict and store capacity

**`get(key)`**

- If key not in dict → return -1
- Else:
    - Move to end (mark as most recently used)
    - Return value

**`put(key, value)`**

- If key exists:
    - Move to end and update value
- If key doesn’t exist:
    - Add new key
    - If capacity exceeded → pop from front

---

### 🧠 Key Interview Insights

- `OrderedDict` abstracts doubly linked list internally
- If implementing from scratch:
    - Use a dict and your own `Node` + doubly linked list class
- Still O(1) due to pointer rewiring and dict lookups

---

### ✅ Time & Space

- Time: O(1) for `get` and `put`
- Space: O(capacity)

---

### 🔥 Summary Quote for Interviews

> “I used an OrderedDict to combine hash map lookup with ordered usage tracking. move_to_end() and popitem(last=False) allow us to update and evict keys in O(1). The approach satisfies both functionality and efficiency guarantees of an LRU cache.”
> 

---